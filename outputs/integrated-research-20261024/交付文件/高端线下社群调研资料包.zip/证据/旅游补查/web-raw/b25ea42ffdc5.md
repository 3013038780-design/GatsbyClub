[ ![Other Way Round](https://i0.wp.com/otherwayround.travel/wp-content/uploads/2018/02/website_logo.png?w=264) ](https://www.otherwayround.travel/)
  * [TRIPS](https://www.otherwayround.travel/how-it-works/)
    * [All Trip Dates](https://www.otherwayround.travel/trip-dates/)
    * [Africa](https://www.otherwayround.travel/how-it-works/)
      * [Kenya & Tanzania (10-days)](https://www.otherwayround.travel/kenya-tanzania-10-days/)
      * [Morocco (9-days)](https://www.otherwayround.travel/morocco-9-days/)
      * [South Africa & Victoria Falls (10-days)](https://www.otherwayround.travel/south-africa-victoria-falls-10-days/)
    * [Asia](https://www.otherwayround.travel/how-it-works/)
      * [India (14-days)](https://www.otherwayround.travel/india-14-days/)
      * [Japan (11-days)](https://www.otherwayround.travel/japan-11-days/)
      * [Jordan (8-days)](https://www.otherwayround.travel/jordan-8-days/)
      * [Thailand (11-days)](https://www.otherwayround.travel/thailand-11-days/)
      * [Vietnam & Cambodia (15-days)](https://www.otherwayround.travel/vietnam-cambodia-15-days/)
    * [Europe](https://www.otherwayround.travel/how-it-works/)
      * [Albania (8-days)](https://www.otherwayround.travel/albania-8-days/)
      * [Croatia (8-days)](https://www.otherwayround.travel/croatia-8-days/)
      * [Greece (8-days)](https://www.otherwayround.travel/greece-8-days/)
      * [Italy (8-days)](https://www.otherwayround.travel/italy-8-days/)
      * [Portugal (8-days)](https://www.otherwayround.travel/portugal-8-days/)
      * [Prague, Vienna, Budapest (8-days)](https://www.otherwayround.travel/prague-vienna-budapest-8-days/)
      * [Scandinavia (8-days)](https://www.otherwayround.travel/scandinavia-8-days/)
    * [Oceania](https://www.otherwayround.travel/how-it-works/)
      * [New Zealand (12-days)](https://www.otherwayround.travel/new-zealand-12-days/)
    * [The Americas](https://www.otherwayround.travel/how-it-works/)
      * [Argentina (11-days)](https://www.otherwayround.travel/argentina-11-days/)
      * [Brazil (12-days)](https://www.otherwayround.travel/brazil-12-days/)
      * [Colombia (11-days)](https://www.otherwayround.travel/colombia-11-days/)
      * [Costa Rica (9-days)](https://www.otherwayround.travel/costa-rica-9-days/)
      * [Guatemala & Belize (10-days)](https://www.otherwayround.travel/guatemala-belize-10-days/)
      * [Mexico (11-days)](https://www.otherwayround.travel/mexico-11-days/)
      * [Mexico City (4-days)](https://www.otherwayround.travel/mexico-city-4-days/)
      * [Peru (12-days)](https://www.otherwayround.travel/peru-12-days/)
    * [Which Trip?](https://www.otherwayround.travel/which-trip-is-right-for-you/)
  * [TRIP STYLE](https://www.otherwayround.travel/owr-trip-style/)
  * [HOW IT WORKS](https://www.otherwayround.travel/how-it-works/)
  * [REVIEWS](https://www.otherwayround.travel/reviews/)
  * [BLOG](https://www.otherwayround.travel/blog/)
  * [ABOUT](https://www.otherwayround.travel/about-us/)
  * [MY OWR](https://otherwayround.wetravel.com/ "For guests currently booked onto an OWR trip")
  * [ENQUIRE NOW](https://www.otherwayround.travel/enquire-now/)


Select Page
# HOW IT WORKS !
# HOW IT WORKS !
## An Overview
We run cool trips to exotic locations we know inside out.
You simply rock up, with zero worries about logistics or planning, open to meeting new people and enjoying new experiences.
There will be between 4 and 15 people on every trip (we average 10). They will be of a similar age. At a similar stage in life. Also traveling solo.
Almost everything is included from the point you land into the destination, but, not your international flights to get there.
You will stay in very nice hotels, eat brilliant food and enjoy high quality experiences.
It’s super fun. There’s a nice social atmosphere. **[And our past guests love us!](https://www.otherwayround.travel/reviews/)**
![Other Way Round group tour in Morocco](https://www.otherwayround.travel/wp-content/uploads/2023/11/owr-how-it-works-4.jpg)
## Booking a Trip
It’s very easy.
You pay a **£200/$250 deposit** now and then the remaining balance 70 days (10 weeks) before the trip.
That deposit is non-refundable, but, it can be transferred to a different trip if you can no longer make it.
The remaining balance can be paid off in one lump sum, or, we can set up a payment plan.
When you’re ready to book simply navigate to your preferred trip page and select “Book Now”. This will take you through the checkout process where you can pay your deposit via Visa, Mastercard, ApplePay, Amex, Bank Transfer etc…
Afterwards, you will receive a confirmation email that your spot is reserved.
From that point onwards, you can book your international flights (don’t leave this too late – flights generally get more expensive the closer you get).
**Contact us: info@otherwayround.travel**
![Other Way Round group tour in Colombia](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1080'%20height='810'%20viewBox='0%200%201080%20810'%3E%3C/svg%3E)
## Lead Up To Trip
**10 WEEKS BEFORE**
You must have paid your full balance by 70 days (10 weeks) before the trip – this is when we confirm numbers to local suppliers on the ground.
Afterwards we will send you our **“pre-trip information” document** – providing a lot more detail about your upcoming trip: visas, weather, packing lists, vaccines etc…
We will also send you a survey asking for things like flight details, emergency contacts, health conditions, dietary preferences, passport copy etc…This allows us to start organising the finer details of the trip.
**1 WEEK BEFORE**
You will receive an email with a detailed **hr-by-hr schedule** and a list of **recommended optional activities** (for any free days). There will also be some final pieces of info related to airport transfers, welcome meeting etc…
**3 DAYS BEFORE**
A few days before the trip we also create a **WhatsApp group** connecting you with everyone else joining.
![Other Way Round group tour in Colombia](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1080'%20height='810'%20viewBox='0%200%201080%20810'%3E%3C/svg%3E)
## During Trip
Your **Tour Leader** will run the trip as scheduled, managing any issues that occur along the way.
(Here we remind you to keep in mind all the points highlighted in our **[OWR Trip Style](https://www.otherwayround.travel/owr-trip-style/)** document) 
![Other Way Round group tour in Medellin, Colombia](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1080'%20height='810'%20viewBox='0%200%201080%20810'%3E%3C/svg%3E)
## Post Trip
We will send you a survey asking for **feedback** on your experience (if there’s anything you’d like to discuss in more detail you can also email us at **info@otherwayround.travel**)
You can already hear from our past guests in their **[testimonials](https://www.otherwayround.travel/reviews/)**.
We also have some special offers to those on our trips:-
  * **if you book a new trip within 2 weeks of your current trip ending, you get a £200 / $250 discount**


  * **if you book a new trip after this point, we still offer a £100 / $125 discount**


![Other Way Round group tour in Peru](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='1080'%20height='810'%20viewBox='0%200%201080%20810'%3E%3C/svg%3E)
## FAQs
Below are some of the common questions we tend to get asked – we’ve answered both in video format (longer version) and written format (quicker).
![YouTube video](data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='480'%20height='360'%20viewBox='0%200%20480%20360'%3E%3C/svg%3E)
[](https://www.otherwayround.travel/how-it-works/)
**Video Timestamps:**
00:00 Intro
00:33 How It Works
03:00 Demographics
07:25 What’s the Price?
08:04 What’s Included?
10:42 Which Hotels?
12:10 Are Airport Transfers Included?
13:31 Room Sharing / Private Rooms
16:02 Booking & Cancellation Terms
20:30 “I Found the Same Tour for Cheaper”
23:37 I’m an Introvert!
24:54 Is Every Activity Mandatory?
26:02 What Happens After Booking?
27:58 Can I Bring a Friend?
30:50 Are You a Good Fit for OWR?
32:42 Where Is OWR Based?
33:31 Why Should I Choose OWR?
37:35 More Questions?
Below is the written answer to many of the same questions:
**What’s Included in the Price?**
At the top of every itinerary page there is a section explicitly stating what’s included and what’s not.
Most things are included from the point you land into the destination – airport transfers, hotels, tour guides, activities, internal transport & most of the food.
The big thing not included is the international flights to get there.
**When is the Best Time to Book Flights?**
After we have confirmed your place on our trip, you can go ahead and book your flights. Remember, the later you leave it the more expensive they will get.
**When Should I Arrive and Leave?**
Ideally you want to arrive and be at the hotel before 6pm on the first day of the trip. We know that is not always possible though due to flight times from your location. We will decide on the ‘welcome meeting’ time when we have everyone’s flight details.
You can leave at any time on the last day of the trip as we don’t have activities planned for that day.
If you want to tag on extra days at the start or end of the trip, you are completely welcome. Let us know if you want to book at our hotel and we can help (up to a maximum of 2 days on either side).
If you need any advice on flights, get in touch.
**Are Airport Transfers Included?**
Yes, they are included at both the start and end of every trip.
Notes
  * We only do transfers between airport and our hotels. No other locations.
  * For those tagging on extra days, we will endeavour to include transfers up to 2 days outside of official tour dates (there is an exception on our Mexico itinerary where we only include the departure transfer on the last day of the tour).


**Can I Pay Extra for a Private Room?**
As standard, the prices on our website are based on sharing a twin hotel room with someone of the same gender.
You can however, pay extra for a private room.
Prices for this are shown at the bottom of each itinerary page.
(Note – we have limited availability of private rooms, these will be allocated on a first come, first served basis).
**I’m Traveling Solo, Will I Be the Only One?**
No! You will be in the majority. Our trips are full of people in a similar situation looking to meet and travel with other solo travelers so you will fit in perfectly.
**Who Comes on Our Trips?**
The vast majority of people will be:-
  * From the UK, USA, Canada, Australia (although we welcome people from all over)
  * In their 30s & 40s (30–49)
  * Traveling solo


**Can I Bring a Friend?**
Yes, of course, you are very welcome to bring a friend along.
Like we said above however, the majority of the group will be traveling solo, so, if you can’t convince your friend to join, you should come along anyway (you will probably get more out of the experience if you travel alone).
**Can you set up a payment plan?**
Yes.
**I Found this Itinerary Cheaper Elsewhere!**
Firstly, our aim is not to be the cheapest – it’s to do the best trips! (and with the best people of course)
However, if you found seemingly the “same” itinerary at a cheaper price it will almost always be because:-
  * We are using much better hotels
  * We are eating at much better restaurants
  * Our activities/experiences are of higher quality
  * We include just about everything within our trips, whereas, if you drill into other itineraries a lot will probably be optional meaning you pay much more during the trip itself.


**Can You Handle Food Restrictions?**
Yes, we have many people joining our trips who are vegetarian, vegan or with other specific dietary requirements. We work with our restaurants to accommodate.
**What’s the Cancellation Policy?**
The £200/$250 deposit is non-refundable. However, if you need to cancel at any point, you can put this towards any future trip you book with us (in any location).
The rest of the balance is refundable up until 10 weeks before the trip. From that point we have to start committing funds to local suppliers and so:-
> 30-70 days before trip – 50% refund
> 0–30 days before trip – 0% refund
We also recommend that you take out **travel insurance** to cover you for any unexpected last-minute cancellation.
  * [HOME](https://www.otherwayround.travel/)
  * [PRIVACY POLICY](https://www.otherwayround.travel/privacy-policy/)
  * [BOOKING TERMS](https://www.otherwayround.travel/booking-terms-and-conditions/)
  * [ENQUIRE NOW](https://www.otherwayround.travel/enquire-now/)


Copyright © 2026 Other Way Round Travel
By continuing to browse this site you are agreeing to our [use of cookies](https://www.otherwayround.travel/privacy-policy/). I Understand
